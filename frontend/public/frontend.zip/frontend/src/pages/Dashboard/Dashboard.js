import React from 'react'
import Events from '../../components/Events.js'


//Remover
const Dashboard = () => {
  return (
    <Events/>
  )
}

export default Dashboard;