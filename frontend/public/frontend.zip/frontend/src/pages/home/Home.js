import React from 'react'


//Remover
const Home = () => {
  return (
    <div>Home</div>
  )
}

export default Home;